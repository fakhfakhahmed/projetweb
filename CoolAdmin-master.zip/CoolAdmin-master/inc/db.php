<?php

$con = mysqli_connect("localhost","root","","sisagri2");

?>
