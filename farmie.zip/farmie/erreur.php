<?php include 'header.php'; ?>
<section>

	<form method="post"  name="f" action="inc/views/ajouterclient.php" >
<div class="col-12 col-lg-5">
	<div class="contact-content mb-100">
		<!-- Section Heading -->
		<div class="section-heading">
			<p>Contact now</p>
			<h2><span>Get In Touch</span> With Us</h2>
			<img src="img/core-img/decor.png" alt="">
		</div>
		<!-- Contact Form Area -->
		<div class="contact-form-area">
	<h1>OUPS... this account has been blocked</h1>




				</div>

		</div>
	</div>
</div>

</form>
</section>
<?php include 'footer.php'; ?>
